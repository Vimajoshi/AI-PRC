/*
Power of a number

power(+Num, +Pow, -Ans)
    Ans is Num**Pow.
*/
power(Num, Pow, Ans) :- Ans is Num ** Pow.